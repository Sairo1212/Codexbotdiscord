const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require("discord.js");
const { General, BList, Tickesettings } = require("../Database/index");


async function definicoes1(client, interaction) {

    interaction.update({
        embeds: [
            new EmbedBuilder()
                .setAuthor({ name: `Definir Cargos`, iconURL: "https://cdn.discordapp.com/emojis/1265528449561526343.webp?size=96&quality=lossless" })
                .setDescription(`Olá, Sr(a) **${interaction.user.username}**\n \n- **Selecione abaixo a opção deseja configurar.** \n
**Cargo de Administrador:** ${General.get(`admrole`) == null ? `\`Não definido\`` : `<@&${General.get(`admrole`)}>`}
**Cargo de Suporte:** ${General.get(`staffrole`) == null ? `\`Não definido\`` : `<@&${General.get(`staffrole`)}>`}
**Cargo de Membro:** ${General.get(`rolemember`) == null ? `\`Não definido\`` : `<@&${General.get(`rolemember`)}>`}
                    `)
                .setColor(General.get("oficecolor.main"))
                .setFooter({ text: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('changecargoadmin')
                        .setLabel('Cargo de Admnistrador')
                        .setStyle(1)
                        .setEmoji('1251441849130946572'),
                    new ButtonBuilder()
                        .setCustomId('changecargostaff')
                        .setLabel('Cargo de Suporte')
                        .setStyle(1)
                        .setEmoji('1241951076434055178'),
                    new ButtonBuilder()
                        .setCustomId("changecargomembru")
                        .setLabel('Cargo de Membros')
                        .setStyle(1)
                        .setEmoji('1261435261653483611')
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltarDefinitions")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji('1265111272312016906')
                )
        ],
        ephemeral: true
    });
}

async function definicoes2(client, interaction) {
    interaction.update({
        embeds: [
            new EmbedBuilder()
                .setAuthor({ name: `Definir Canais de Logs`, iconURL: "https://cdn.discordapp.com/emojis/1265528447418105940.webp?size=96&quality=lossless" })
                .setDescription(`Olá, Sr(a) **${interaction.user.username}**\n \n- **Selecione abaixo a opção deseja configurar.** \n
**Canal de log de Tickets:** ${General.get(`logsticketChannel`) == null ? `\`Não definido\`` : `<#${General.get(`logsticketChannel`)}>`}
**Canal de logs de Entradas:** ${General.get(`logsbemvindu`) == null ? `\`Não definido\`` : `<#${General.get(`logsbemvindu`)}>`}
**Canal de logs de Saidas:** ${General.get(`logsaidas`) == null ? `\`Não definido\`` : `<#${General.get(`logsaidas`)}>`}
**Canal de logs de Bans:** ${General.get(`logsBan`) == null ? `\`Não definido\`` : `<#${General.get(`logsBan`)}>`}
**Canal de logs de Castigos:** ${General.get(`logsCastigo`) == null ? `\`Não definido\`` : `<#${General.get(`logsCastigo`)}>`}
**Canal de logs da Blacklist:** ${General.get(`logsBlacklist`) == null ? `\`Não definido\`` : `<#${General.get(`logsBlacklist`)}>`}
**Canal de logs Gerais do Sistema:** ${General.get(`logsGerais`) == null ? `\`Não definido\`` : `<#${General.get(`logsGerais`)}>`}
                    `)
                .setColor(General.get("oficecolor.main"))
                .setFooter({ text: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("logTicketsss")
                        .setLabel('Logs de Ticket')
                        .setStyle(1)
                        .setEmoji('1267032211455082508'),
                    new ButtonBuilder()
                        .setCustomId("logsEntradass")
                        .setLabel('Logs de Entradas')
                        .setStyle(1)
                        .setEmoji('1267032211455082508'),
                    new ButtonBuilder()
                        .setCustomId("saidalogs")
                        .setLabel('Logs de Saidas')
                        .setStyle(1)
                        .setEmoji('1267032211455082508')
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("loogsBan")
                        .setLabel("Logs de Bans")
                        .setStyle(1)
                        .setEmoji('1267032211455082508'),
                    new ButtonBuilder()
                        .setCustomId("loogscastigu")
                        .setLabel("logs de Castigo")
                        .setStyle(1)
                        .setEmoji('1267032211455082508'),
                    new ButtonBuilder()
                        .setCustomId("logsBlackliist")
                        .setLabel('Logs Blacklist')
                        .setEmoji('1267032211455082508')
                        .setStyle(1)
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("logissGerais")
                        .setLabel("Logs Gerais")
                        .setStyle(1)
                        .setEmoji('1267032211455082508')
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltarDefinitions")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji('1265111272312016906')
                )
        ],
        ephemeral: true
    });
}

async function definitions(client, interaction) {
    interaction.update({
        embeds: [
            new EmbedBuilder()
                .setAuthor({ name: `Definições Gerais`, iconURL: "https://cdn.discordapp.com/emojis/1265528445123694593.webp?size=96&quality=lossless" })
                .setDescription(`Olá Sr(a) **${interaction.user.username}**\n \n- **Selecione abaixo a opção que deseja configurar.** \n`)
                .setColor(General.get("oficecolor.main"))
                .setFooter({ text: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('config_cargos')
                        .setLabel('Gerenciar Cargos')
                        .setStyle(1)
                        .setEmoji('1271659788614373399'),
                    new ButtonBuilder()
                        .setCustomId("config_logs")
                        .setLabel("Gerenciar Logs")
                        .setStyle(1)
                        .setEmoji('1271659788614373399'),
                    new ButtonBuilder()
                        .setCustomId("config_Pixx")
                        .setLabel("Definir Pix")
                        .setStyle(1)
                        .setEmoji('1147900305304977408')
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar1")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji('1265111272312016906')
                )
        ],
        ephemeral: true
    });
}

async function configPiix(client, interaction) {
    interaction.update({
        embeds: [
            new EmbedBuilder()
                .setAuthor({ name: `Gerenciar Pix`, iconURL: "https://cdn.discordapp.com/emojis/1265528455072841831.webp?size=96&quality=lossless" })
                .setDescription(`Olá Sr(a) **${interaction.user.username}**\n \n- **Selecione abaixo a opção que deseja configurar.** \n`)
                .setColor(General.get("oficecolor.main"))
                .setFooter({ text: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('config_cargos')
                        .setLabel('Gerenciar Cargos')
                        .setStyle(1)
                        .setEmoji('1271659788614373399'),
                    new ButtonBuilder()
                        .setCustomId("config_logs")
                        .setLabel("Gerenciar Logs")
                        .setStyle(1)
                        .setEmoji('1271659788614373399'),
                    new ButtonBuilder()
                        .setCustomId("config_Pixx")
                        .setLabel("Definir Pix")
                        .setStyle(1)
                        .setEmoji('1147900305304977408')
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar1")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji('1265111272312016906')
                )
        ],
        ephemeral: true
    });
}

module.exports = {
    definitions,
    definicoes1,
    definicoes2
}