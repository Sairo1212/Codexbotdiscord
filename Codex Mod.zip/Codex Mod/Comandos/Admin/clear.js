const Discord = require("discord.js")
const {ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandOptionType} = require("discord.js")
const { General } = require("../../Database/index");

module.exports = {
    name: "clear", 
    description: "[STAFF] clear channel messages", 
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'quantidade',
            description: 'insira a quantidade de mensagens que deseja apagar.',
            type: ApplicationCommandOptionType.Number,
            required: true,
        }
    ],

    run: async (client, interaction) => {

        let numero = interaction.options.getNumber('quantidade')

        if (interaction.user.id !== General.get('owner') && !interaction.member.roles.cache.has(General.get("admrole"))) {
            interaction.reply({
                content: `Espere! Você não tem permissão para usar este comando`, ephemeral: true
            });
            return;
        } else {

            if (parseInt(numero) > 99 || parseInt(numero) <= 0) {

                interaction.reply({content:`Você só pode apagar até 99 mensagens por vez`})

            } else {

                interaction.reply({content:`Apagando as mensagens..`, ephemeral:true})
                
                try {
                    await interaction.channel.bulkDelete(parseInt(numero))
                    setTimeout(() => {
                        interaction.editReply({content:`Operação concluida com sucesso!`, ephemeral:true })
                    }, 1000)

                } catch(error) {
                    console.log(error)
                    interaction.editReply({content:`Você não pode apagar mensagens com 14 dias de diferença entre uma e outra.`});
                }
            }

        }

    }
}