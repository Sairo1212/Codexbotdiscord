const { ApplicationCommandType, ButtonBuilder, ActionRowBuilder, EmbedBuilder } = require("discord.js");
const { General, BList, Tickesettings } = require("../../Database/index");
const startTime = Date.now();

module.exports = {
    name: "recursos",
    description: "[STAFF] Click by to use my features",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== General.get('owner') && !interaction.member.roles.cache.has(General.get("admrole"))) {
            interaction.reply({
                content: `Espere! Você não tem permissão para usar este comando`, ephemeral: true
            });
            return;
        }

        interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setAuthor({ name: client.user.username, iconURL: "https://cdn.discordapp.com/emojis/1265111276237881454.webp?size=96&quality=lossless" })
                    .setTitle(`**Painel Geral**`)
                    .setDescription(`Olá, Sr(a) **${interaction.user.username}**.\n\n- Nosso sistema é completamente personalizavel,\n customize-o da maneira que preferir.`)
                    .addFields(
                        { name: "**Current Version**", value: `\`1.0.0\``, inline: true },
                        { name: "**Latency**", value: `\`${client.ws.ping} ms\``, inline: true },
                        { name: `**Uptime**`, value: `<t:${Math.ceil(startTime / 1000)}:R>`, inline: true }
                    )
                    .setColor(General.get("oficecolor.main"))
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                    .setTimestamp()
            ],
            components: [
                new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('gerenciarerTicket')
                            .setLabel('Painel Ticket')
                            .setStyle(1)
                            .setEmoji('1263226742399832160'),
                        new ButtonBuilder()
                            .setCustomId('moderationn')
                            .setLabel('Painel Moderação')
                            .setStyle(1)
                            .setEmoji('1251441849130946572')
                    ),

                new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('bemvindou')
                            .setLabel('Boas-vindas')
                            .setStyle(1)
                            .setEmoji('1261427087542059058'),
                        new ButtonBuilder()
                            .setCustomId('personalizarapp')
                            .setLabel('Customizar')
                            .setStyle(1)
                            .setEmoji('1251441839404220417'),
                        new ButtonBuilder()
                            .setCustomId('definiicao')
                            .setStyle(2)
                            .setEmoji('1271659788614373399')
                    ),               
            ],
            ephemeral: true
        });
    }
};
