const {
    JsonDatabase,
  } = require("wio.db");


  const General = new JsonDatabase({
    databasePath: "./Database/settings.json"
  });

  const BList = new JsonDatabase({
    databasePath: "./Database/blacklist.json"
  });

  const tickets = new JsonDatabase({
    databasePath: "./Database/tickets.json"
  });

  const announce = new JsonDatabase({
    databasePath: "./Database/anunciar.json"
  });

  const welcomis = new JsonDatabase({
    databasePath: "./Database/boasvindas.json"
  });

  module.exports = {
    General,
    BList,
    tickets,
    announce,
    welcomis
  }